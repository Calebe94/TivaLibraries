#include"tm4c123gh6pm.h"

void SSI0_init(uint8_t clock, uint8_t divider);

void SSI0_write(uint8_t data);
