#include "I2C.h"
#include "MAX30100.h"

bool begin(I2C *device){
	
}
